module.exports = json2Plugin

function json2Plugin() {
	require('./lib/json2')
	return {}
}
