var port = 9575
var tunnel = require('./saucelabs/tunnel')

tunnel.setup(port, function(err, url) {
	console.log("Tunnel up and running at", url)
})
